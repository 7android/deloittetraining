package com.hms.deloitte.model;

public class Payment {

}
